package com.example.scuffed_spotify

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
