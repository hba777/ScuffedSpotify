import 'package:flutter/material.dart';
import 'package:syncfusion_flutter_charts/charts.dart';
import 'package:scuffed_spotify/api/apis.dart'; // Import your APIs file
import '../models/song_class.dart'; // Import your AutoGenerate class

class ChartsScreen extends StatelessWidget {
  final AutoGenerate auto;

  ChartsScreen({required this.auto});

  @override
  Widget build(BuildContext context) {
    return Theme(
      data: ThemeData(
        appBarTheme: AppBarTheme(
          iconTheme: IconThemeData(color: Colors.white), // Set back button color to white
        ),
      ),
      child: Scaffold(
        backgroundColor: Colors.blueGrey[900],
        appBar: AppBar(
          title: Text('Chart for ${auto.trackName}', style: TextStyle(color: Colors.white)),
          backgroundColor: Colors.blueGrey,
        ),

        body: Column(
          children: [
            // Add other UI elements if needed
            Expanded(
              child: SfCircularChart(
                title: ChartTitle(
                  text: 'Song Properties',
                  textStyle: TextStyle(color: Colors.white), // Set title text color to white
                ),
                  legend: Legend(
                    isVisible: true,
                    textStyle: TextStyle(color: Colors.white), // Set legend text color to white
                  ),
                series: <DoughnutSeries<Map<String, dynamic>, String>>[
                  DoughnutSeries<Map<String, dynamic>, String>(
                    dataSource: [
                      {'metric': 'Energy', 'value': auto.energy},
                      {'metric': 'Loudness', 'value': auto.loudness},
                      {'metric': 'Key', 'value': auto.keyValue},
                      {'metric': 'Mode', 'value': auto.modeValue},
                      {'metric': 'Speechiness', 'value': auto.speechiness},
                      {'metric': 'Acousticness', 'value': auto.acousticness},
                      {'metric': 'Instrumentalness', 'value': auto.instrumentalness},
                      {'metric': 'Liveness', 'value': auto.liveness},
                      {'metric': 'Valence', 'value': auto.valence},
                    ],
                    xValueMapper: (Map<String, dynamic> data, _) => data['metric'],
                    yValueMapper: (Map<String, dynamic> data, _) => double.parse(data['value'].toString()),
                    dataLabelSettings: DataLabelSettings(
                      isVisible: true,
                      textStyle: TextStyle(color: Colors.white), // Set data label text color to white
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
